<?php return 'you will need to login to the Google API console to get your own key';
