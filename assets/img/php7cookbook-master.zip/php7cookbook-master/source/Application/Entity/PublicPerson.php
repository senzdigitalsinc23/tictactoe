<?php
namespace Application\Entity;

class PublicPerson
{
	private $id = NULL;
	public $firstName  = '';
	public $lastName   = '';
	public $address    = '';
	public $city 	   = '';
	public $stateProv  = '';
	public $postalCode = '';
	public $country    = '';
}
