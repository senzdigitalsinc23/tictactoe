<?php
// parsing tree structures
namespace Application\Parse;

/*
 * This class contains properties of an XML Path
 */

class XmlPath
{
    public $name  = '';
    public $path  = '';
    public $parts = array();
}
