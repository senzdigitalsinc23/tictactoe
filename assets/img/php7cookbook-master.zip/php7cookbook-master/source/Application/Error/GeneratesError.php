<?php
namespace Application\Error;

class GeneratesError
{
    public function __construct($arg)
    {
        // do nothing
    }
}
