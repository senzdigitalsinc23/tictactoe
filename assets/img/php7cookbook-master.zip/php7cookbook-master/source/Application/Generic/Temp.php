<?php
namespace Application\Generic;

/**
 * This is a demonstration class which uses classes in other namespaces
 *
 */
class Temp
{
}
