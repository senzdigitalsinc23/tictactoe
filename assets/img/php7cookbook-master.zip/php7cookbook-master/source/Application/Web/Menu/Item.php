<?php
namespace Application\Web;

class Item
{
	public $label;
	public $url;
	public $li;
	public $dropDown;
	public $items;
}
