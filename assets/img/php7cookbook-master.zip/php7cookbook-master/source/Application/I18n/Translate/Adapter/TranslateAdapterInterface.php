<?php
namespace Application\I18n\Translate\Adapter;

interface TranslateAdapterInterface
{
	public function translate($msgid);
}
