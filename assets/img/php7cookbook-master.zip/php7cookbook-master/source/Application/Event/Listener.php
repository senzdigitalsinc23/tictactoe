<?php
namespace Application\Event;

class Listener
{
    public $alias = array();
    public $listeners = array();
}
