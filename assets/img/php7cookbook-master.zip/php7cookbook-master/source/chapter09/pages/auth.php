<?php
    // authenticate
?>
<h1>Request</h1>
<?= $auth->getLoginForm($action) ?>
<h1>Response</h1>
<pre><?php var_dump($response); ?></pre>
<br>
<hr>
NOTE: see /path/to/source/data/files/customer_passwords.txt
<br><br>Examples:
<ul>
    <li>raymond.sanford@cablenet.net:swim5067you</li>
    <li>tabitha.foster@westcom.com:arm4342gazed</li>
    <li>jose.carter@westcom.net:asked3261of</li>
</ul>
