<?php
    // intermediate content
?>
<h1>Page 9</h1>
<hr>
<p>Satisne vobis videor pro meo iure in vestris auribus commentatus? Sed haec quidem liberius ab eo dicuntur et saepius. At iste non dolendi status non vocatur voluptas. Honesta oratio, Socratica, Platonis etiam. Laboro autem non sine causa; Non semper, inquam; Cur igitur, inquam, res tam dissimiles eodem nomine appellas? Sin dicit obscurari quaedam nec apparere, quia valde parva sint, nos quoque concedimus; Bestiarum vero nullum iudicium puto. Quorum sine causa fieri nihil putandum est.</p>
<p>Idem iste, inquam, de voluptate quid sentit? Istam voluptatem perpetuam quis potest praestare sapienti? Ex rebus enim timiditas, non ex vocabulis nascitur. Negare non possum. Pisone in eo gymnasio, quod Ptolomaeum vocatur, unaque nobiscum Q. Et quidem iure fortasse, sed tamen non gravissimum est testimonium multitudinis. Vidit Homerus probari fabulam non posse, si cantiunculis tantus irretitus vir teneretur; Gerendus est mos, modo recte sentiat. Tamen a proposito, inquam, aberramus. Expectoque quid ad id, quod quaerebam, respondeas. </p>
