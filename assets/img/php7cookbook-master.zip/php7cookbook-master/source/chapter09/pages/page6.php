<?php
    // intermediate content
?>
<h1>Page 6</h1>
<hr>
<p>Cum praesertim illa perdiscere ludus esset. Quod ea non occurrentia fingunt, vincunt Aristonem; Primum Theophrasti, Strato, physicum se voluit; Ab his oratores, ab his imperatores ac rerum publicarum principes extiterunt. Omnes enim iucundum motum, quo sensus hilaretur.</p>
<p>Idem iste, inquam, de voluptate quid sentit? Non modo carum sibi quemque, verum etiam vehementer carum esse? Non est enim vitium in oratione solum, sed etiam in moribus. Graccho, eius fere, aequalí? Omnia contraria, quos etiam insanos esse vultis. In qua quid est boni praeter summam voluptatem, et eam sempiternam? </p>
