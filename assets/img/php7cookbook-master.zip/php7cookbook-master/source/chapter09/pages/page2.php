<?php // page 2 ?>
<h1>Page 2</h1>
<hr>
<table style="width: 800px;">
    <tr>
        <td>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Estne, quaeso, inquam, sitienti in bibendo voluptas? Illis videtur, qui illud non dubitant bonum dicere -; Inquit, dasne adolescenti veniam? Minime vero istorum quidem, inquit. Age, inquies, ista parva sunt.</p>
        <p>Illa sunt similia: hebes acies est cuipiam oculorum, corpore alius senescit; Duo Reges: constructio interrete. Quod quidem nobis non saepe contingit. Quid ad utilitatem tantae pecuniae? Quid nunc honeste dicit? Aliter homines, aliter philosophos loqui putas oportere? Quibusnam praeteritis? Quid enim me prohiberet Epicureum esse, si probarem, quae ille diceret?</p>
        </td>
        <td>
            <img src="/planet.png" width=300 />
        </td>
    </tr>
</table>
