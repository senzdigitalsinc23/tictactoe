<!DOCTYPE html>
<head>
	<title>PHP 7 Cookbook</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
</head>
<body>
<table>
	<tr>
		<td>&#x1F648;</td>
		<td>&#x1F649;</td>
		<td>&#x1F64A;</td>
	</tr>
	<tr>
		<td><?php echo "\u{1F648}"; ?></td>
		<td><?php echo "\u{1F649}"; ?></td>
		<td><?php echo "\u{1F64A}"; ?></td>
	</tr>
</table>
</body>
</html>
