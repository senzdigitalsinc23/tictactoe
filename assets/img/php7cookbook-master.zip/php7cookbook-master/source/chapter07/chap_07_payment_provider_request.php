<?php
// merchant:
// business@unlikelysource.com / p.a.s.s.w.o.r.d.
// Client ID: AZk46FOq95u6kLygTeu3sgM0_Hv3KBntGWLNpRDpsuQZKf5q4CHzxBEaoo2uu1ZXuE98UikgCZEdcJ8R
// Secret: EKfMFTMxsQqLoSUP4074bEZP1Upg4Mi4mBrnNus7zm83F1kF6ydjl_grKKV-Ae9QPYSdb7n83LOGnixt
